import AsyncStorage from '@react-native-async-storage/async-storage';

const TRANSACTION_KEY = 'transactions';

export const getTransactions = async () => {
  try {
    const jsonValue = await AsyncStorage.getItem(TRANSACTION_KEY);
    return jsonValue != null ? JSON.parse(jsonValue) : [];
  } catch (e) {
    console.error(e);
    return [];
  }
};

export const saveTransaction = async (transaction) => {
  try {
    const transactions = await getTransactions();
    transactions.push(transaction);
    await AsyncStorage.setItem(TRANSACTION_KEY, JSON.stringify(transactions));
  } catch (e) {
    console.error(e);
  }
};
