import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function TransactionItem({ item }) {
  return (
    <View style={styles.item}>
      <Text>{item.date} - {item.note}</Text>
      <Text style={{ color: item.type === 'income' ? 'green' : 'red' }}>
        {item.type === 'income' ? '+' : '-'}{item.amount} บาท
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  item: { flexDirection: 'row', justifyContent: 'space-between', padding: 10, borderBottomWidth: 1 }
});
