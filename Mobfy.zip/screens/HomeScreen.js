import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { getTransactions } from '../utils/storage';

export default function HomeScreen({ navigation }) {
  const [balance, setBalance] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      const transactions = await getTransactions();
      const total = transactions.reduce((acc, item) => {
        return item.type === 'income' ? acc + item.amount : acc - item.amount;
      }, 0);
      setBalance(total);
    };
    const unsubscribe = navigation.addListener('focus', fetchData);
    return unsubscribe;
  }, [navigation]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>ยอดคงเหลือของคุณ</Text>
      <Text style={styles.balance}>{balance.toLocaleString()} บาท</Text>

      <TouchableOpacity style={styles.buttonAdd} onPress={() => navigation.navigate('Add Transaction')}>
        <Text style={styles.buttonText}>➕ เพิ่มรายการ</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.buttonHistory} onPress={() => navigation.navigate('History')}>
        <Text style={styles.buttonText}>📜 ดูประวัติ</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#f0f4f7', 
    justifyContent: 'center', 
    alignItems: 'center', 
    padding: 20 
  },
  title: { 
    fontSize: 24, 
    color: '#333', 
    marginBottom: 10 
  },
  balance: { 
    fontSize: 40, 
    fontWeight: 'bold', 
    color: '#4caf50', 
    marginBottom: 30 
  },
  buttonAdd: {
    backgroundColor: '#4caf50',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 15,
    marginBottom: 15,
    width: '80%',
    alignItems: 'center',
    shadowColor: '#000', shadowOpacity: 0.2, shadowOffset: { width: 0, height: 2 }, shadowRadius: 5,
  },
  buttonHistory: {
    backgroundColor: '#2196f3',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 15,
    width: '80%',
    alignItems: 'center',
    shadowColor: '#000', shadowOpacity: 0.2, shadowOffset: { width: 0, height: 2 }, shadowRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold'
  }
});
