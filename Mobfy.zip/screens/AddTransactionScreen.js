import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { saveTransaction } from '../utils/storage';

export default function AddTransactionScreen({ navigation }) {
  const [amount, setAmount] = useState('');
  const [type, setType] = useState('expense');
  const [note, setNote] = useState('');

  const handleSave = async () => {
    if (!amount || isNaN(amount)) {
      alert('กรุณากรอกจำนวนเงินให้ถูกต้อง');
      return;
    }
    await saveTransaction({
      id: Date.now().toString(),
      type,
      amount: parseFloat(amount),
      note: note || 'ไม่มีหมายเหตุ',
      date: new Date().toISOString().split('T')[0]
    });
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>เพิ่มรายการใหม่</Text>

      <Text style={styles.label}>จำนวนเงิน</Text>
      <TextInput
        style={styles.input}
        keyboardType="numeric"
        value={amount}
        onChangeText={setAmount}
        placeholder="เช่น 500"
      />

      <Text style={styles.label}>ประเภท</Text>
      <View style={styles.typeContainer}>
        <TouchableOpacity
          style={[styles.typeButton, type === 'expense' && styles.selectedExpense]}
          onPress={() => setType('expense')}
        >
          <Text style={styles.typeText}>รายจ่าย</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.typeButton, type === 'income' && styles.selectedIncome]}
          onPress={() => setType('income')}
        >
          <Text style={styles.typeText}>รายรับ</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.label}>หมายเหตุ</Text>
      <TextInput
        style={styles.input}
        value={note}
        onChangeText={setNote}
        placeholder="หมายเหตุ (ไม่บังคับ)"
      />

      <TouchableOpacity style={styles.buttonSave} onPress={handleSave}>
        <Text style={styles.buttonText}>💾 บันทึก</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f4f7', padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', textAlign: 'center', marginBottom: 20 },
  label: { marginTop: 15, fontSize: 16, fontWeight: '600' },
  input: { 
    borderWidth: 1, borderColor: '#ccc', padding: 10, marginTop: 5, borderRadius: 10,
    backgroundColor: '#fff'
  },
  typeContainer: { flexDirection: 'row', justifyContent: 'space-around', marginVertical: 20 },
  typeButton: { paddingVertical: 10, paddingHorizontal: 20, borderRadius: 10, backgroundColor: '#eee' },
  selectedExpense: { backgroundColor: '#ff8a80' },
  selectedIncome: { backgroundColor: '#80d8ff' },
  typeText: { fontSize: 16 },
  buttonSave: {
    backgroundColor: '#4caf50',
    marginTop: 30,
    paddingVertical: 15,
    borderRadius: 15,
    alignItems: 'center',
    shadowColor: '#000', shadowOpacity: 0.2, shadowOffset: { width: 0, height: 2 }, shadowRadius: 5,
  },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' }
});
